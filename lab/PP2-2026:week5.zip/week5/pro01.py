class Point:
    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z

class Point3D(Point):
    def __init__(self, x=0, y=0, z=0):
        super().__init__(x, y, z)
        
    def __str__(self):
        return f"{self.x}, {self.y}, {self.z}"

p = Point3D(10, 20, 30)
print(p)